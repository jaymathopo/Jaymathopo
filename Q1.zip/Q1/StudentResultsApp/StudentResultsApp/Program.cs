﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Variables
        string studentName;
        double mark1, mark2, mark3;
        double total, average;

        // Input student name
        Console.Write("Enter student name: ");
        studentName = Console.ReadLine();

        // Input and validate marks
        mark1 = GetValidMark("Enter mark for Subject 1: ");
        mark2 = GetValidMark("Enter mark for Subject 2: ");
        mark3 = GetValidMark("Enter mark for Subject 3: ");

        // Calculations
        total = mark1 + mark2 + mark3;
        average = total / 3;

        // Determine result
        string result = (average >= 50) ? "PASS" : "FAIL";

        // Output
        Console.WriteLine("\n====== STUDENT RESULTS ======");
        Console.WriteLine("Student Name: " + studentName);
        Console.WriteLine("Total Marks: " + total);
        Console.WriteLine("Average Marks: " + average);
        Console.WriteLine("Result: " + result);
        Console.WriteLine("Result Issued At: " + DateTime.Now);

        Console.WriteLine("\nPress any key to exit...");
        Console.ReadKey();
    }

    // Method to validate numeric input
    static double GetValidMark(string message)
    {
        double mark;
        bool isValid;

        do
        {
            Console.Write(message);
            isValid = double.TryParse(Console.ReadLine(), out mark);

            if (!isValid)
            {
                Console.WriteLine("Invalid input! Please enter a numeric value.");
            }

        } while (!isValid);

        return mark;
    }
}